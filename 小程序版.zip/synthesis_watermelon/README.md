# synthesis_watermelon 
  微信小游戏，合成大西瓜
# 如何使用 
  使用微信开发者导入小游戏即可

# 展示
![avatar](img/2F3E6B8A4BE936870852FDFCB94C4483.png)
# 注意事项
  本项目仅供个人使用，请不要用作商业用途，如有侵权请联系删除
