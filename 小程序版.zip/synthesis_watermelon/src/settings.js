window._CCSettings = {
    platform: "wechatgame",
    groupList: [ "default" ],
    collisionMatrix: [ [ true ] ],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/scene/MainScene.fire",
    orientation: "portrait",
    server: "",
    jsList: [],
    bundleVers: {
        internal: "39a48",
        resources: "4e034",
        main: "e8a76"
    }
};